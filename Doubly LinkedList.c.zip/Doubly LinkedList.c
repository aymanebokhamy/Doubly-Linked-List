#include <stdio.h>
#include <stdlib.h>


typedef struct node_{
  int value;
  struct node_* next;
  struct node_* prev;
}node;


void traverse(node *h){
  node *temporary;
  
  temporary = h;

  while(temporary != NULL){
    printf("%d-- ", temporary->value);
    temporary = temporary -> next;
  }
}

node* insert_bfore_h(node *h, node *nh){
    h->prev=nh;
    nh->next = h;
    h = nh;
  return h;
}

node* insert_at_end(node *h, node *n_end, node* pree){
   if(pree->next == NULL){
    pree->next = n_end;
    n_end->prev=pree;
    n_end->next = NULL;
 }

return h;
}

node* delete_first(node *h){
  node *temp = h;

  h = h->next;
  h->prev=NULL;
  free(temp);
return h;
}

node* delete_last(node *h, node *end, node *pre){
  node* ptr = end;

  pre->next = NULL;
  free(ptr);

return h;  
}


int main(void){
    node *head, *walker, *_new, *pre, *new_end, *new_head, *new_middle;
    int ans,ans2, ans3, ans4, p, p2;

 
  head = (node*)malloc(sizeof(node));

  printf("Plz enter a value: ");
  scanf("%d", &head->value);
  head->next=NULL;
  head->prev=NULL;
  walker = head;
    
  do{
    _new = (node*)malloc(sizeof(node));
    _new->next=NULL;
    _new->prev=NULL;
    printf("Value: ");
    scanf("%d", &_new->value);
    walker->next = _new;
    walker = _new;

  printf("Add another node? 1 for Yes or 0 for No: ");
  scanf("%d", &ans);
  }while (ans == 1);
    

  traverse(head);

  new_head = (node*)malloc(sizeof(node));

  printf("Value to insert before the head: ");
  scanf("%d", &new_head->value);

  head = insert_bfore_h(head, new_head);

  traverse(head);

  pre = (node*)malloc(sizeof(node));
  new_end = (node*)malloc(sizeof(node));

  pre = _new;

  printf("Value to insert at the end: ");
  scanf("%d", &new_end->value);

  head = insert_at_end(head, new_end, pre);

  traverse(head);

  new_middle = (node*)malloc(sizeof(node));

  printf("Value to insert at the middle: ");
  scanf("%d", &new_middle->value);

  printf("Enter the position:");
  scanf("%d", &p);

walker=head;
for(int i=1;i<p-1;i++){
    walker=walker->next;      
}
      new_middle->next = walker->next;
      walker->next->prev=new_middle;
      new_middle->prev=walker;
      walker->next = new_middle;
    
    traverse(head);

  printf("Press 1 if you want to delete the first node: ");
  scanf("%d", &ans2);

  if(ans2 == 1){  
    head = delete_first(head);

    traverse(head);
  }

  printf("Press 1 if you want to delete the last node: ");
  scanf("%d", &ans3);
if(ans3 == 1){ 
  
  head = delete_last(head, new_end, pre);
  
  traverse(head);

}
  
  printf("Press 1 if you want to delete a node in the middle: ");
  scanf("%d", &ans4);

  if(ans4 ==1){

    printf("Enter the position:");
    scanf("%d", &p2);

    walker=head;
    for(int i=1;i<p2-1;i++){
      walker=walker->next;
    }

    node* temp = walker->next;
    temp->next->prev=walker;
    walker->next=temp->next;
    walker->next->prev = walker;
    free(temp);

      traverse(head);


  }
  return 0;
}